logicOutput = currentState == 1;
