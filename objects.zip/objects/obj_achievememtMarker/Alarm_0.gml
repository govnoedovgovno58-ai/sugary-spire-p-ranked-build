picy = 640;
