x = collisionboxid.x;
