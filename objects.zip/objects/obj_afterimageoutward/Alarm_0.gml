vanish = 1;
