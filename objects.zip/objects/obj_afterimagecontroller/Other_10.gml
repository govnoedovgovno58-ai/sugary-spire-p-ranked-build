global.BlinkTrail = !global.BlinkTrail;
