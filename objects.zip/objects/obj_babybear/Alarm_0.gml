roaming = 1;
