flash = 0;
