state = global.coneblock;
