enem = 0;
