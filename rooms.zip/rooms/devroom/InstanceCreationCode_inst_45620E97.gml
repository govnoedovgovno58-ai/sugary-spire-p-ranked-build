lap = 1;
