targetRoom = dance_6;
