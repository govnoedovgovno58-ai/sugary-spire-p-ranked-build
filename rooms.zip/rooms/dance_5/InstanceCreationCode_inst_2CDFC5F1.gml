targetRoom = dance_treasure;
