targetDoor = "C";
