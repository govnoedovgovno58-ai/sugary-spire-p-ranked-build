targetRoom = dragonlair_8;
