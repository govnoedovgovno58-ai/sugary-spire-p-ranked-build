targetDoor = "S";
