targetRoom = dance_pillar;
