firstGumslime = true;
