targetRoom = dragonlair_5;
