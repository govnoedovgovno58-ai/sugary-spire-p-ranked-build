targetRoom = mines_14;
