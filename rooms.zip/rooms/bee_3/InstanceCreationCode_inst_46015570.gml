targetRoom = bee_1;
