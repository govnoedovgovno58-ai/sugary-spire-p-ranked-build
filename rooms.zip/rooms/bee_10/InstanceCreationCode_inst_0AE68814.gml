targetDoor = "A";
