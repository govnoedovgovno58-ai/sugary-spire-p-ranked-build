targetRoom = mines_13;
