targetRoom = mines_6;
