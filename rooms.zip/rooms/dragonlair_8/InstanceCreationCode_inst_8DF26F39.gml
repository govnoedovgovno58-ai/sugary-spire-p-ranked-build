targetRoom = dragonlair_9;
