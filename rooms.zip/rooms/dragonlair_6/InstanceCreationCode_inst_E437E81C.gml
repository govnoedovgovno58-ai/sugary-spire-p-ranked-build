targetRoom = dragonlair_7;
