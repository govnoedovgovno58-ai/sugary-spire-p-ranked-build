targetRoom = exitway_3;
