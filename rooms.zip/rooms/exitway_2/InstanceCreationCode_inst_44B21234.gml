targetRoom = exitway_1;
