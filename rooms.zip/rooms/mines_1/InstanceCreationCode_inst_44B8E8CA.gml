targetRoom = mines_2;
