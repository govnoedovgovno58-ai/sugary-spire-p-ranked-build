targetRoom = mines_11;
