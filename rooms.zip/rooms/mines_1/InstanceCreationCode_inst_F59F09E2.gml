targetRoom = mines_3;
