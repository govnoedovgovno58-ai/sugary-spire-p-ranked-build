targetRoom = mines_8;
