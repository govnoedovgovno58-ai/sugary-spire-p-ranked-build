targetRoom = mines_7;
