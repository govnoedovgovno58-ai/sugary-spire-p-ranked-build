targetRoom = mines_treasure;
