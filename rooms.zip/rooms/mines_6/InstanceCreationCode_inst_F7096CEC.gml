targetRoom = mines_9;
