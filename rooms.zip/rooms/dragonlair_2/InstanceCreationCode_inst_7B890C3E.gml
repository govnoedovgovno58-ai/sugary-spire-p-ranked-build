targetRoom = dragonlair_1;
