targetRoom = dragonlair_3;
