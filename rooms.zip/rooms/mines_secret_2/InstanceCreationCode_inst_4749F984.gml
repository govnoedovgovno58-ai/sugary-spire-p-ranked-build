targetDoor = "B";
