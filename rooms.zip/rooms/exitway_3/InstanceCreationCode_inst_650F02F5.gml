targetRoom = exitway_4;
