mytimeigiveyoufortime = 800;
