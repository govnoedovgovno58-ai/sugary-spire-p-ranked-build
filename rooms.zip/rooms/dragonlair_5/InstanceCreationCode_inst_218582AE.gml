targetRoom = dragonlair_6;
