targetRoom = hub_hallway;
