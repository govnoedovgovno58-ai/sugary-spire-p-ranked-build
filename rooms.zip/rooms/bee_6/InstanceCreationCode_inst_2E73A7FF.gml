targetRoom = bee_treasure;
