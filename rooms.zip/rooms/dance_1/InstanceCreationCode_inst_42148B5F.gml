targetRoom = dance_portal;
