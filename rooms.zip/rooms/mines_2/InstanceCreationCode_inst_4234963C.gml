targetRoom = mines_1;
