targetRoom = mines_4;
