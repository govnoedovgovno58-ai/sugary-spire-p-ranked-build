targetRoom = mines_5;
