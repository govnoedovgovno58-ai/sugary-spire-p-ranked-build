targetRoom = exitway_2;
