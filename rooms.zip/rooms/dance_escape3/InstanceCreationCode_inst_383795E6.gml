reciever = true;
