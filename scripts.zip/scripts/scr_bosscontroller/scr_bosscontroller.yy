{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "scr_bosscontroller",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Boss",
    "path": "folders/Scripts/Enemy/Boss.yy",
  },
}