function menu_case(_s)
{
	var _lower = string_lower(string(_s));
	var _out = "";
	var _cap = true;
	for (var i = 1; i <= string_length(_lower); i++)
	{
		var _c = string_char_at(_lower, i);
		if (_c == " ")
			_cap = true;
		else if (_cap)
		{
			_c = string_upper(_c);
			_cap = false;
		}
		_out += _c;
	}
	return string_replace_all(_out, "Sfx", "SFX");
}
function menu_sentence(_s)
{
	var _lower = string_lower(string(_s));
	if (_lower == "")
		return "";
	return string_upper(string_char_at(_lower, 1)) + string_delete(_lower, 1, 1);
}
function draw_option()
{
	draw_set_color(c_white);
	if (argument3 == 0)
		draw_set_color(0x666666);
	draw_text(argument0, argument1, menu_case(argument2));
	draw_set_color(c_white);
}
function draw_option_subtitle(_text)
{
	if (_text == "")
		return;
	var _t = menu_sentence(_text);
	draw_set_font(global.promptfont);
	var _w = string_width(_t) + 32;
	draw_sprite_ext(spr_optionSubtitle, 0, 480, 521, _w / 32, 1, 0, c_white, 1);
	draw_text(480, 505, _t);
}
function draw_slider(_x, _y, _value, _selected, _active)
{
	_value = clamp(_value, 0, 1);
	var _sx = _x - (sprite_get_width(spr_slider) / 2);
	var _tint = _selected ? c_white : 0x888888;
	draw_set_color(c_white);
	draw_sprite_ext(spr_slider, 0, _sx + sprite_get_xoffset(spr_slider), _y, 1, 1, 0, _tint, 1);
	var _dy = 15.5;
	var _ox = _active ? 0 : -1.5;
	var _oy = (_active ? 1 : 5.5) + _dy;
	var _is = 1;
	var _hw = _active ? 13 : 17.5;
	var _kx = _sx + 12 + _hw + ((200 - (_hw * 2)) * _value);
	var _ky = _y + 13.5;
	var _ix = _kx - (((sprite_get_width(spr_slidericon) / 2) - sprite_get_xoffset(spr_slidericon)) + _ox) * _is;
	var _iy = _ky - (((sprite_get_height(spr_slidericon) / 2) - sprite_get_yoffset(spr_slidericon)) + _oy) * _is;
	draw_sprite_ext(spr_slidericon, _active ? 1 : 0, _ix, _iy, _is, _is, 0, _tint, 1);
}