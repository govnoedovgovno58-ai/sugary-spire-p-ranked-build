{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "scr_player_actor",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "States",
    "path": "folders/Scripts/Player/States.yy",
  },
}