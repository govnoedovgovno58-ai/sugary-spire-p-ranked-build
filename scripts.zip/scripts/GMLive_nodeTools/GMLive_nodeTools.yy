{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "GMLive_nodeTools",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "GMLive",
    "path": "folders/Extensions/GMLive.yy",
  },
}