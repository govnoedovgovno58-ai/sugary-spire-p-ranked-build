{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "scr_enemy_bounce",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "States",
    "path": "folders/Scripts/Enemy/States.yy",
  },
}