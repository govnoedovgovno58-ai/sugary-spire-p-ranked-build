function scr_custom_init()
{
	global.custom_audio = ds_map_create();
	global.custom_sounds = [
		{ key: "mach1", label: "Mach 1", asset: sound_dash1, path: "" },
		{ key: "mach2", label: "Mach 2", asset: sound_dash2, path: "" },
		{ key: "mach3", label: "Mach 3", asset: sound_dash3, path: "" },
		{ key: "mach4", label: "Mach 4", asset: sound_dash4, path: "" },
		{ key: "clide", label: "Mach clide boost", asset: sound_maximumspeedstop, path: "" },
		{ key: "waffle", label: "Crunchy construction music", asset: mu_waffle, path: "" },
		{ key: "escape", label: "Sugar rush music", asset: mu_escape, path: "" },
		{ key: "lap", label: "Lap 2 music", asset: mu_lap, path: "" }
	];
	global.custom_msg = "";
	global.custom_msg_timer = 0;
	global.custom_costume_sprite = -4;
	global.custom_costume_path = "";
	global.custom_costume_dirty = false;
	global.custom_costume_trash = [];
	ini_open("optionData.ini");
	global.opt_hidefg = ini_read_real("Custom", "hidefg", 0);
	global.opt_coneboyspd = ini_read_real("Custom", "coneboyspd", 8);
	global.opt_speeddemon = ini_read_real("Custom", "speeddemon", 0);
	global.opt_spawnconeboy = ini_read_real("Custom", "spawnconeboy", 0);
	global.opt_combospd = ini_read_real("Custom", "combospd", 1);
	global.opt_killercombo = ini_read_real("Custom", "killercombo", 0);
	var _paths = [];
	for (var i = 0; i < array_length(global.custom_sounds); i++)
		array_push(_paths, ini_read_string("Custom", "snd_" + global.custom_sounds[i].key, ""));
	var _costume = ini_read_string("Custom", "costume", "");
	ini_close();
	for (i = 0; i < array_length(_paths); i++)
	{
		if (_paths[i] != "")
			scr_custom_load_sound(i, _paths[i], false);
	}
	// Custom Clothing временно отключён: сохранённый костюм не подгружаем.
	// Чтобы вернуть, раскомментируй две строки ниже:
	// if (_costume != "")
	//	scr_custom_costume_select(_costume, false);
}
function scr_custom_allowed()
{
	return (room == hub_w1 || room == hub_w2);
}
function scr_custom_message(_text)
{
	global.custom_msg = _text;
	global.custom_msg_timer = 180;
}
function scr_custom_save_opt(_key, _val)
{
	ini_open("optionData.ini");
	ini_write_real("Custom", _key, _val);
	ini_close();
}
function scr_custom_resolve(_s)
{
	if (is_undefined(_s) || !variable_global_exists("custom_audio"))
		return _s;
	var _c = ds_map_find_value(global.custom_audio, _s);
	return is_undefined(_c) ? _s : _c;
}

// ---------------------------------------------------------------- ЗВУКИ (OGG)
function scr_custom_free_sound(_asset)
{
	var _old = ds_map_find_value(global.custom_audio, _asset);
	if (!is_undefined(_old))
	{
		audio_stop_sound(_old);
		audio_destroy_stream(_old);
		ds_map_delete(global.custom_audio, _asset);
	}
}
function scr_custom_load_sound(_i, _path, _msg)
{
	var _e = global.custom_sounds[_i];
	var _err = "The game supports audio formats such as OGG.";
	if (string_lower(filename_ext(_path)) != ".ogg" || !file_exists(_path))
	{
		if (_msg)
			scr_custom_message(_err);
		return false;
	}
	var _snd = audio_create_stream(_path);
	if (_snd < 0)
	{
		show_debug_message("[custom] OGG not supported: " + _path);
		if (_msg)
			scr_custom_message(_err);
		return false;
	}
	scr_custom_free_sound(_e.asset);
	ds_map_set(global.custom_audio, _e.asset, _snd);
	_e.path = _path;
	return true;
}
function scr_custom_pick_sound(_i)
{
	var _path = get_open_filename_ext("OGG audio|*.ogg", "", working_directory, "Choose an OGG file");
	if (_path == "")
		return;
	if (scr_custom_load_sound(_i, _path, true))
	{
		ini_open("optionData.ini");
		ini_write_string("Custom", "snd_" + global.custom_sounds[_i].key, _path);
		ini_close();
	}
}
function scr_custom_reset_sound(_i)
{
	var _e = global.custom_sounds[_i];
	scr_custom_free_sound(_e.asset);
	_e.path = "";
	ini_open("optionData.ini");
	ini_key_delete("Custom", "snd_" + _e.key);
	ini_close();
	scr_custom_message("The setting has been reset to normal values");
}

// ---------------------------------------------------------------- КОСТЮМЫ
function scr_custom_check_costume(_path)
{
	var _err = "The costume must be 32 by 32 pixels in size!";
	if (string_lower(filename_ext(_path)) != ".png" || !file_exists(_path))
	{
		scr_custom_message(_err);
		return -4;
	}
	var _spr = sprite_add(_path, 1, false, false, 0, 0);
	if (_spr < 0)
	{
		show_debug_message("[custom] sprite_add failed: " + _path);
		scr_custom_message(_err);
		return -4;
	}
	if (sprite_get_width(_spr) != 32 || sprite_get_height(_spr) != 32)
	{
		show_debug_message("[custom] bad costume size: " + string(sprite_get_width(_spr)) + "x" + string(sprite_get_height(_spr)));
		sprite_delete(_spr);
		scr_custom_message(_err);
		return -4;
	}
	return _spr;
}
function scr_custom_costume_list_read()
{
	var _arr = [];
	ini_open("optionData.ini");
	var _n = ini_read_real("CustomCostumes", "count", 0);
	for (var i = 0; i < _n; i++)
	{
		var _p = ini_read_string("CustomCostumes", "c" + string(i), "");
		if (_p != "" && file_exists(_p))
			array_push(_arr, _p);
	}
	ini_close();
	return _arr;
}
function scr_custom_costume_list()
{
	if (!variable_global_exists("custom_costume_list"))
		global.custom_costume_list = scr_custom_costume_list_read();
	return global.custom_costume_list;
}
function scr_custom_costume_list_save()
{
	var _list = scr_custom_costume_list();
	ini_open("optionData.ini");
	ini_section_delete("CustomCostumes");
	ini_write_real("CustomCostumes", "count", array_length(_list));
	for (var i = 0; i < array_length(_list); i++)
		ini_write_string("CustomCostumes", "c" + string(i), _list[i]);
	ini_close();
}
function scr_custom_costume_add()
{
	var _path = get_open_filename_ext("PNG image|*.png", "", working_directory, "Choose a 32x32 PNG");
	if (_path == "")
		return false;
	var _spr = scr_custom_check_costume(_path);
	if (_spr == -4)
		return false;
	sprite_delete(_spr);
	var _list = scr_custom_costume_list();
	for (var i = 0; i < array_length(_list); i++)
	{
		if (_list[i] == _path)
			return true;
	}
	array_push(_list, _path);
	scr_custom_costume_list_save();
	return true;
}
function scr_custom_costume_select(_path, _save)
{
	var _new = -4;
	if (_path != "")
	{
		_new = scr_custom_check_costume(_path);
		if (_new == -4)
			return false;
	}
	var _old = global.custom_costume_sprite;
	if (_old != -4 && sprite_exists(_old))
		array_push(global.custom_costume_trash, _old);   // удалим после применения, не сразу
	global.custom_costume_sprite = _new;
	global.custom_costume_path = _path;
	global.custom_costume_dirty = true;                  // применится, как только игрок вернётся с паузы
	scr_custom_apply_costume();
	if (_save)
	{
		ini_open("optionData.ini");
		ini_write_string("Custom", "costume", _path);
		ini_close();
	}
	return true;
}
function scr_custom_apply_costume()
{
	if (!instance_exists(obj_player))
		return;   // игрок на паузе деактивирован: применим позже из Step игрока
	with (obj_player)
	{
		var _idx = -1;
		for (var i = 0; i < array_length(my_palettes); i++)
		{
			if (my_palettes[i][0] == "Custom Costume")
			{
				_idx = i;
				break;
			}
		}
		if (global.custom_costume_sprite != -4)
		{
			if (_idx == -1)
			{
				new_palette("Custom Costume", global.custom_costume_sprite, 13150344);
				_idx = array_length(my_palettes) - 1;
			}
			else
				my_palettes[_idx][2][2] = global.custom_costume_sprite;
			paletteselect = _idx;
		}
		else if (_idx != -1)
		{
			if (paletteselect == _idx)
				paletteselect = 0;
			my_palettes[_idx][2][2] = -4;
		}
	}
	global.custom_costume_dirty = false;
	for (var j = 0; j < array_length(global.custom_costume_trash); j++)
	{
		if (sprite_exists(global.custom_costume_trash[j]))
			sprite_delete(global.custom_costume_trash[j]);
	}
	global.custom_costume_trash = [];
}
function scr_custom_draw_preview(_x, _y, _scale)
{
	var _spr = spr_player_idle;
	var _idx = floor(current_time / 100) mod sprite_get_number(_spr);
	var _pat = global.custom_costume_sprite;
	if (_pat != -4 && sprite_exists(_pat))
		scr_palette_as_player(_spr, _idx, _pat);
	else if (instance_exists(obj_player))
		scr_palette_as_player(_spr, _idx);
	draw_sprite_ext(_spr, _idx, _x, _y, _scale, _scale, 0, c_white, 1);
	pal_swap_reset();
}

// ---------------------------------------------------------------- OTHER
function scr_custom_apply_fg()
{
	var _layers = layer_get_all();
	for (var i = 0; i < array_length(_layers); i++)
	{
		var _bg = layer_background_get_id(_layers[i]);
		if (_bg == -1)
			continue;
		var _spr = layer_background_get_sprite(_bg);
		if (_spr == fg_fudgetop1 || _spr == fg_fudgetop2 || _spr == fg_fudgetop3)
			layer_background_visible(_bg, !global.opt_hidefg);
	}
}
function scr_custom_room_start()
{
	scr_custom_apply_fg();
	if (global.opt_spawnconeboy && global.levelname != "none" && scr_roomcheck() && instance_exists(obj_player) && !instance_exists(obj_coneball))
		instance_create(obj_player.x, obj_player.y, obj_coneball);
}